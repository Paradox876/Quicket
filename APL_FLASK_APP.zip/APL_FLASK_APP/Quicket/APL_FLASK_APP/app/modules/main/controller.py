class MainController:
    def index(self):
        return {'message':'Hello, World!'}
